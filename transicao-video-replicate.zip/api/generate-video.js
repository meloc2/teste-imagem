
export default async function handler(req, res) {
  const replicateApiKey = process.env.REPLICATE_API_KEY;

  if (req.method === "POST") {
    const { image1, image2 } = req.body;
    const response = await fetch("https://api.replicate.com/v1/predictions", {
      method: "POST",
      headers: {
        "Authorization": `Token ${replicateApiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        version: "a85eb9e9d75819bba76cdbf6b3c70d1b5a9ad1012aa8b1ac0d8e29bdbb17fcd5",
        input: { image1, image2 }
      })
    });

    const data = await response.json();
    res.status(response.status).json(data);
  }

  if (req.method === "GET") {
    const id = req.query.id;
    const response = await fetch(`https://api.replicate.com/v1/predictions/${id}`, {
      headers: {
        "Authorization": `Token ${replicateApiKey}`
      }
    });

    const data = await response.json();
    res.status(response.status).json(data);
  }
}
